# BreatheSafe — mobile-ready air quality app

This updated package keeps the original BreatheSafe visual theme and sections while fixing the main data-rendering error and improving small-screen behaviour.

## Included sections
- Home dashboard and current model AQI
- Tamil Nadu district map and district selector
- Six pollutant readings
- Air-quality alerts
- Hourly PM2.5 insights chart
- Health & safety guide
- About and developer information
- Downloadable text report

## Run locally
A Progressive Web App (PWA) needs HTTPS or localhost for installation and offline caching. From this folder:

```bash
python -m http.server 8000
```

Open `http://localhost:8000` on your computer. To test on a phone on the same Wi-Fi network, use your computer's local network IP and port 8000. For installation on Android, publish this folder to an HTTPS static host, open it in Chrome, then choose **Install app** or **Add to Home screen**.

## Data behaviour
The app retrieves current and hourly air-quality model output from the Open-Meteo Air Quality API (CAMS). It displays the returned US AQI and pollutant concentrations. A copy of the last successful result for the selected district is saved in browser storage and can be shown when a later refresh cannot connect.

Values are model estimates, not direct sensor readings, not verified government monitoring-station readings, and not India's official CPCB AQI. District map pins are representative district-centre coordinates, not official station locations. A working internet connection is needed for fresh data, map tiles and external map/font assets.

## Troubleshooting
- If the page was already open before replacing the files, close it and reopen it. The updated service worker uses a new cache version.
- If old files still appear, clear the site's cached data once or reload the site after it reconnects.
- If no fresh data appears, check the internet connection; saved readings may still be shown with their saved-data label.
- Browser local storage is specific to that browser/device. It does not sync data between a phone and a computer.

## Android APK
This is a mobile-installable PWA source package, not a compiled APK. It can be installed on Android through an HTTPS deployment using Chrome's **Install app** option. A signed APK requires an Android build environment and signing configuration.

## Sources
- Open-Meteo Air Quality API / CAMS model output: https://open-meteo.com/en/docs/air-quality-api
- OpenStreetMap map tiles and contributors: https://www.openstreetmap.org/copyright
