const districts=[
['Ariyalur',11.14,79.08],['Chengalpattu',12.69,79.98],['Chennai',13.08,80.27],['Coimbatore',11.02,76.96],['Cuddalore',11.75,79.77],['Dharmapuri',12.13,78.16],['Dindigul',10.37,77.98],['Erode',11.34,77.72],['Kallakurichi',11.74,78.96],['Kancheepuram',12.83,79.70],['Kanniyakumari',8.09,77.54],['Karur',10.96,78.08],['Krishnagiri',12.52,78.21],['Madurai',9.93,78.12],['Mayiladuthurai',11.10,79.65],['Nagapattinam',10.77,79.84],['Namakkal',11.22,78.17],['Nilgiris',11.41,76.70],['Perambalur',11.23,78.88],['Pudukkottai',10.38,78.82],['Ramanathapuram',9.36,78.83],['Ranipet',12.93,79.33],['Salem',11.66,78.15],['Sivaganga',9.84,78.48],['Tenkasi',8.96,77.31],['Thanjavur',10.79,79.14],['Theni',10.01,77.48],['Thoothukudi',8.76,78.13],['Tiruchirappalli',10.79,78.70],['Tirunelveli',8.71,77.76],['Tirupathur',12.50,78.57],['Tiruppur',11.11,77.34],['Tiruvallur',13.14,79.91],['Tiruvannamalai',12.23,79.07],['Tiruvarur',10.77,79.63],['Vellore',12.92,79.13],['Viluppuram',11.94,79.49],['Virudhunagar',9.58,77.96]
];

const $ = s => document.querySelector(s);
let selected = districts.find(d => d[0] === 'Tiruchirappalli');
let latest = null, map = null, markers = [], requestId = 0;
const CACHE_KEY = 'breathesafe-last-data-v2';
const SELECTED_KEY = 'breathesafe-selected-district';
const params = d => new URLSearchParams({
  latitude:d[1], longitude:d[2],
  current:'pm2_5,pm10,nitrogen_dioxide,sulphur_dioxide,ozone,carbon_monoxide,us_aqi',
  hourly:'pm2_5,pm10', forecast_days:'2', timezone:'Asia/Kolkata'
}).toString();

function showToast(message) {
  const el=$('#toast'); if(!el)return;
  el.textContent=message; el.classList.add('show');
  clearTimeout(showToast.timer); showToast.timer=setTimeout(()=>el.classList.remove('show'),2600);
}
function category(value) {
  if(value==null || !Number.isFinite(Number(value))) return ['Unavailable',''];
  if(value<=50)return ['Good','good'];
  if(value<=100)return ['Moderate','moderate'];
  if(value<=150)return ['Unhealthy for sensitive groups','moderate'];
  if(value<=200)return ['Unhealthy','poor'];
  if(value<=300)return ['Very unhealthy','poor'];
  return ['Hazardous','poor'];
}
function num(value) {
  if(value==null || !Number.isFinite(Number(value))) return '—';
  return Number(value).toFixed(1);
}
function formattedTime(value) {
  if(!value)return 'Time unavailable';
  const d=new Date(value);
  return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleString('en-IN',{dateStyle:'medium',timeStyle:'short'});
}
function setStatus(message) {
  const el=$('#updatedAt'); if(el)el.textContent=message;
}
function go(page) {
  document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+page));
  document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('selected',b.dataset.page===page));
  if(page==='map')setTimeout(()=>{initMap();if(map)map.invalidateSize();},120);
  if(page==='insights')setTimeout(drawChart,100);
  if(page==='monitor')renderPollutants();
  window.scrollTo({top:0,behavior:'smooth'});
}
document.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.page)));
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));

function saveCache(data) {
  try { localStorage.setItem(CACHE_KEY,JSON.stringify({district:selected[0],data,savedAt:new Date().toISOString()})); } catch(e) {}
}
function loadCache() {
  try {
    const saved=JSON.parse(localStorage.getItem(CACHE_KEY)||'null');
    if(!saved || !saved.data || !saved.data.current || saved.district!==selected[0])return false;
    latest=saved.data;
    renderAll();
    setStatus('Saved data · '+formattedTime(saved.savedAt)+' · Refresh for latest');
    $('#dataBadge').textContent='SAVED MODEL DATA';
    return true;
  } catch(e) { return false; }
}
async function loadData() {
  const thisRequest=++requestId, btn=$('#refreshBtn');
  if(btn){btn.disabled=true;btn.textContent='…';}
  setStatus('Connecting to air-quality data service…');
  try {
    const controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),15000);
    let response;
    try {
      response=await fetch('https://air-quality-api.open-meteo.com/v1/air-quality?'+params(selected),
        {cache:'no-store',signal:controller.signal});
    } finally { clearTimeout(timeout); }
    if(!response.ok)throw new Error('Data service returned '+response.status);
    const data=await response.json();
    if(thisRequest!==requestId)return;
    if(!data.current)throw new Error('Current data is not available for this location');
    latest=data; saveCache(data); renderAll();
    showToast('Latest available model data loaded');
  } catch(error) {
    if(thisRequest!==requestId)return;
    const hadCache=loadCache();
    setStatus(hadCache?'Showing previously saved data · Internet refresh failed':'Data unavailable · Check internet and try again');
    showToast(hadCache?'Connection unavailable · Showing saved data':'Could not load data. Please try again.');
    console.warn('BreatheSafe data error:',error);
  } finally {
    if(thisRequest===requestId && btn){btn.disabled=false;btn.textContent='↻';}
  }
}
function renderAll() {
  if(!latest || !latest.current)return;
  const c=latest.current, aq=c.us_aqi;
  $('#selectedLocation').textContent=selected[0]+', Tamil Nadu';
  $('#aqiValue').textContent=aq??'—';
  $('#ringValue').textContent=aq??'—';
  $('#aqiLabel').textContent=category(aq)[0]+' · US AQI scale';
  setStatus('Model output time: '+formattedTime(c.time));
  $('#dataBadge').textContent='MODEL ESTIMATE';
  const metrics=[
    ['PM2.5',c.pm2_5,'Fine particles'],
    ['PM10',c.pm10,'Coarse particles'],
    ['NO₂',c.nitrogen_dioxide,'Nitrogen dioxide'],
    ['O₃',c.ozone,'Ozone']
  ];
  $('#metricGrid').innerHTML=metrics.map(x=>`<div class="metric"><span>${x[0]}</span><b>${num(x[1])}</b><small>${x[2]} · µg/m³</small></div>`).join('');
  $('#monitorPlace').textContent=selected[0]+', Tamil Nadu';
  $('#monitorTime').textContent='Model time: '+formattedTime(c.time);
  const [tipTitle,tipText]=aq==null
    ?['Check local air conditions','No current model index is available. Check official local advisories.']
    :aq<=50?['Conditions look relatively favourable','Continue checking updates and follow local guidance.']
    :aq<=100?['Be mindful of changing conditions','Sensitive individuals may prefer to reduce prolonged strenuous outdoor activity.']
    :['Consider reducing outdoor exertion','Check official local advisories, especially if you are sensitive to air pollution.'];
  $('#tipTitle').textContent=tipTitle; $('#tipText').textContent=tipText;
  renderPollutants(); renderAlert(); updateDistrictCard();
  if(document.querySelector('#page-insights.active'))drawChart();
}
function renderPollutants() {
  const list=$('#pollutantList'); if(!list)return;
  if(!latest || !latest.current) {
    list.innerHTML='<div class="info-card"><b>Waiting for air-quality data</b><p>Connect to the internet and refresh to load pollutant levels.</p></div>';return;
  }
  const c=latest.current, rows=[
    ['PM2.5','Fine particulate matter','pm2_5'],
    ['PM10','Coarse particulate matter','pm10'],
    ['Nitrogen dioxide (NO₂)','Traffic and combustion-related gas','nitrogen_dioxide'],
    ['Sulphur dioxide (SO₂)','Combustion-related gas','sulphur_dioxide'],
    ['Ozone (O₃)','Ground-level ozone','ozone'],
    ['Carbon monoxide (CO)','Combustion-related gas','carbon_monoxide']
  ];
  list.innerHTML=rows.map(x=>`<div class="pollutant-row"><div><b>${x[0]}</b><small>${x[1]}</small></div><div class="pollutant-value">${num(c[x[2]])}<small>µg/m³</small></div></div>`).join('');
}
function renderAlert() {
  const panel=$('#alertPanel'); if(!panel)return;
  if(!latest || !latest.current) {
    panel.innerHTML='<div class="alert-symbol">…</div><h2>Waiting for air data</h2><p>Refresh to check the latest available estimate.</p>';return;
  }
  const a=latest.current.us_aqi, label=category(a)[0];
  const title='Air quality: '+label;
  const body=a==null?'The model did not return an AQI value. Check official local advisories.':
    a<=50?'The model index is in the lower range. Keep checking updates.':
    a<=100?'Sensitive individuals should monitor conditions and follow local advice.':
    'Consider limiting prolonged strenuous outdoor activity and follow official advisories.';
  panel.innerHTML=`<div class="alert-symbol">${a!=null&&a<=50?'✓':'!'}</div><h2>${title}</h2><p>${body}</p><small class="muted">Based on modelled US AQI · ${formattedTime(latest.current.time)}</small>`;
}
function initMap() {
  if(map)return;
  if(!window.L){$('#map').innerHTML='<p class="map-message">Map needs an internet connection. You can still choose a district below.</p>';return;}
  map=L.map('map',{zoomControl:true,scrollWheelZoom:false}).setView([10.9,78.5],6.5);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18,attribution:'&copy; OpenStreetMap'}).addTo(map);
  districts.forEach(d=>{
    const marker=L.circleMarker([d[1],d[2]],{radius:7,color:'#fff',weight:2,fillColor:'#20a477',fillOpacity:.95}).addTo(map);
    marker.bindTooltip(d[0]); marker.on('click',()=>selectDistrict(d[0])); markers.push(marker);
  });
  const sel=$('#districtSelect');
  sel.innerHTML=districts.map(d=>`<option value="${d[0]}">${d[0]}</option>`).join('');
  sel.value=selected[0];
  sel.addEventListener('change',()=>selectDistrict(sel.value));
  updateDistrictCard();
}
async function selectDistrict(name) {
  const found=districts.find(d=>d[0]===name); if(!found)return;
  selected=found;
  latest=null;
  try{localStorage.setItem(SELECTED_KEY,name);}catch(e){}
  const sel=$('#districtSelect');if(sel)sel.value=name;
  $('#selectedLocation').textContent=name+', Tamil Nadu';
  if(map)map.setView([selected[1],selected[2]],8);
  $('#districtResult').innerHTML=`<b>${name}</b><p class="muted">Loading latest available model estimate…</p>`;
  await loadData();
  if(latest)updateDistrictCard();
}
function updateDistrictCard() {
  const el=$('#districtResult');if(!el)return;
  if(!latest || !latest.current) {
    el.innerHTML='<b>Choose a district</b><p>District air-quality information will appear here after data loads.</p>';return;
  }
  const c=latest.current;
  el.innerHTML=`<b>${selected[0]}</b><p>US AQI model index: <strong>${c.us_aqi??'—'}</strong> · PM2.5: <strong>${num(c.pm2_5)} µg/m³</strong> · PM10: <strong>${num(c.pm10)} µg/m³</strong></p><p class="muted">Model grid point · ${formattedTime(c.time)}</p>`;
}
function drawChart() {
  const cv=$('#trendChart');if(!cv)return;
  const ctx=cv.getContext('2d'), width=Math.max(260,cv.clientWidth||300), height=190, dpr=window.devicePixelRatio||1;
  cv.width=Math.round(width*dpr);cv.height=Math.round(height*dpr);
  ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,width,height);
  const hourly=latest?.hourly, values=hourly?.pm2_5||[], times=hourly?.time||[];
  const start=latest?.current?.time;
  let startIndex=start?times.findIndex(t=>t>=start):0;
  if(startIndex<0)startIndex=0;
  const vals=values.slice(startIndex,startIndex+24);
  if(!vals.length){ctx.fillStyle='#718179';ctx.font='12px sans-serif';ctx.fillText('Hourly trend is not available.',15,35);return;}
  const valid=vals.filter(v=>v!=null).map(Number);
  if(!valid.length){ctx.fillText('No hourly values returned.',15,35);return;}
  const max=Math.max(10,...valid), left=34,right=12,top=14,bottom=30,plotH=height-top-bottom,plotW=width-left-right;
  ctx.strokeStyle='#e6eee9';ctx.lineWidth=1;ctx.fillStyle='#718179';ctx.font='10px sans-serif';
  for(let i=0;i<4;i++){const y=top+plotH*i/3;ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(width-right,y);ctx.stroke();ctx.fillText((max*(1-i/3)).toFixed(0),3,y+3);}
  ctx.beginPath();let started=false;
  vals.forEach((v,i)=>{if(v==null)return;const x=left+plotW*i/Math.max(1,vals.length-1),y=top+plotH*(1-Number(v)/max);if(!started){ctx.moveTo(x,y);started=true;}else ctx.lineTo(x,y);});
  if(started){ctx.strokeStyle='#16835c';ctx.lineWidth=2.5;ctx.stroke();ctx.lineTo(width-right,height-bottom);ctx.lineTo(left,height-bottom);ctx.closePath();ctx.fillStyle='rgba(32,164,119,.12)';ctx.fill();}
  const labels=[0,Math.floor((vals.length-1)/2),vals.length-1];
  labels.forEach((i,n)=>{const t=times[startIndex+i];const label=t?new Date(t).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'}):['Now','12h','24h'][n];const x=left+plotW*i/Math.max(1,vals.length-1);ctx.fillStyle='#718179';ctx.fillText(label,Math.max(left,Math.min(width-right-35,x-15)),height-8);});
}
function downloadReport() {
  if(!latest || !latest.current){showToast('Load air data first');return;}
  const c=latest.current;
  const report=`BreatheSafe Air Quality Summary
Location: ${selected[0]}, Tamil Nadu
Model time: ${c.time}
US AQI (model): ${c.us_aqi??'Unavailable'}
PM2.5: ${num(c.pm2_5)} µg/m³
PM10: ${num(c.pm10)} µg/m³
NO2: ${num(c.nitrogen_dioxide)} µg/m³
SO2: ${num(c.sulphur_dioxide)} µg/m³
O3: ${num(c.ozone)} µg/m³
CO: ${num(c.carbon_monoxide)} µg/m³

Source: Open-Meteo Air Quality API / CAMS model output. These are model estimates, not direct monitoring-station readings or official Indian CPCB AQI.`;
  const url=URL.createObjectURL(new Blob([report],{type:'text/plain;charset=utf-8'}));
  const a=document.createElement('a');a.href=url;a.download='BreatheSafe-report.txt';document.body.appendChild(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),1000);showToast('Report downloaded');
}
$('#refreshBtn').addEventListener('click',loadData);
$('#downloadReport').addEventListener('click',downloadReport);
window.addEventListener('resize',()=>{if(document.querySelector('#page-insights.active'))drawChart();if(map)map.invalidateSize();});
try {
  const savedDistrict=localStorage.getItem(SELECTED_KEY);
  if(savedDistrict){const found=districts.find(d=>d[0]===savedDistrict);if(found)selected=found;}
} catch(e) {}
loadCache();
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
loadData();
